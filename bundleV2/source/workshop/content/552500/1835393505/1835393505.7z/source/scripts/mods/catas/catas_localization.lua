return {
	mod_description = {
		en = "Adds Cataclysm 2 and Cataclysm 3 to Adventure Maps.",
	},
	hero_power = {
		en = "900 Hero Power"
	},
	hero_power_description = {
		en = "Set's you Hero Power to 900. Which is the max in Weaves which Cata 2 & 3 is balanced around."
	},
}
